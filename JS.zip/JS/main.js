let h1=document.getElementById('h1')
let h2=document.getElementById('h2')
let input=document.getElementById('input')
let button=document.getElementById('button')




// let text = input.value
function butto() {
    h2.innerText=input.value
    input.value=''
}
